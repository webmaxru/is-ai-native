# Is AI-Native Standalone CLI

The standalone CLI provides a terminal interface for the shared scan engine used across the project.

For the GitHub CLI extension export surface, see `../gh-extension/README.md`.

## Status

- Package name: `is-ai-native`
- Executable: `is-ai-native`
- Scope: local filesystem scans and GitHub repository scans
- Distribution: publishable npm package backed by a bundled runtime artifact

## Install From npm

After the first npm publish, these commands will work:

```powershell
npm install is-ai-native
npx is-ai-native --help
```

This package requires Node.js 22 or newer.

## Run From Source

From the repository root:

```powershell
npm install
node packages/cli/bin/cli.js --help
```

To expose the `is-ai-native` command in your shell during local development:

```powershell
npm install
npm link .\packages\cli
is-ai-native --help
```

To verify the packaged artifact locally before publishing:

```powershell
npm --prefix packages/cli pack
npx .\packages\cli\is-ai-native-0.1.2.tgz --help
```

## Usage

```powershell
is-ai-native scan <target> [--output json|human|csv|summary] [--branch <branch>] [--token <token>] [--fail-below <score>]
```

Targets can be:

- a local path such as `.` or `C:\repo`
- a GitHub short reference such as `microsoft/vscode`
- a GitHub URL such as `https://github.com/microsoft/vscode`

Examples:

```powershell
is-ai-native scan . --output human
is-ai-native scan microsoft/vscode --output summary
is-ai-native scan https://github.com/microsoft/vscode --branch main --output json
is-ai-native scan . --output summary --fail-below 60
```

## Output Modes

- `json`: full structured scan result
- `human`: readable console report with a preferred-agent headline plus full per-assistant detail
- `csv`: one row per primitive
- `summary`: one-line CI-friendly output based on the preferred agent

## Exit Codes

- `0`: success
- `1`: usage or runtime error
- `2`: scan completed, but score was below `--fail-below`

## Authentication

For remote GitHub scans, token resolution order is:

1. `--token`
2. `GITHUB_TOKEN`
3. `GH_TOKEN_FOR_SCAN`

Using a token is recommended for repeated scans because unauthenticated GitHub API usage is rate-limited.